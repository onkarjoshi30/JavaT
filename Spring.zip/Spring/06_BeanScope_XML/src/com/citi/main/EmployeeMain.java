package com.citi.main;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.citi.pojo.Address;
import com.citi.pojo.Employee;

public class EmployeeMain {
	public static void main(String[] args) {

		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
		Employee employee1 = context.getBean("employee", Employee.class);
		Employee employee2 = context.getBean("employee", Employee.class);
		Employee employee3 = context.getBean("employee", Employee.class);
		Employee employee4 = context.getBean("employee", Employee.class);

		System.out.println("______________________________________________");
		System.out.println(employee1);
		employee1.setName("Vivek");
		System.out.println(employee1);
		System.out.println(employee1.hashCode());
		System.out.println("______________________________________________");
		System.out.println(employee2);
		System.out.println(employee2.hashCode());
		System.out.println("______________________________________________");
		System.out.println(employee3);
		System.out.println(employee3.hashCode());
		System.out.println("______________________________________________");
		System.out.println(employee4);
		System.out.println(employee4.hashCode());
	}
}