/*package com.citi.pojo;

public class EmployeeMain {
      public static void main(String[] args){
    	  
    	  //create object employee
    	  Employee employee = new Employee();
    	  
    	  //Set values to all its variable
    	  employee.setEmployeeId(101);
    	  employee.setName("Onkar");
    	  employee.setSalary(1000);
    	  
    	  Address address = new Address();
    	  address.setDoorNumber("B-202");
    	  
    	  //get all values of variables and print
      }
}
*/