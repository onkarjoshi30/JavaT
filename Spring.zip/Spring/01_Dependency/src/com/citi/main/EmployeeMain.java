package com.citi.main;

import com.citi.pojo.Address;
import com.citi.pojo.Employee;

public class EmployeeMain {
	public static void main(String[] args) {
		
		//create object of Employee
		Employee employee = new Employee();
		System.out.println("--------------------------------------------------------");
		//set values to all its variables
		employee.setEmployeeId(101);
		employee.setName("Onkar Joshi");
		employee.setSalary(1000);
		
		Address address = new Address();
		address.setDoorNumber("202 , Vinamra");
		address.setStreet("Hadapsar");
		address.setCity("Pune");
		address.setPin(412002);
		
		employee.setAddress(address);
		
		System.out.println("--------------------------------------------------------");
		//get values of all its variables and print.
		System.out.println(employee);
		
		
		
	}
}
