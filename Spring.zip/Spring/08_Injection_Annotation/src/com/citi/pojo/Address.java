package com.citi.pojo;

import org.springframework.stereotype.Component;

@Component
public class Address {
	private String doorNumber;
	private String street;
	private String city;
	private int pin;

	public Address() {
		// TODO Auto-generated constructor stub
	}

	public Address(String doorNumber, String street, String city, int pin) {
		super();
		this.doorNumber = doorNumber;
		this.street = street;
		this.city = city;
		this.pin = pin;
	}

	public String getDoorNumber() {
		return doorNumber;
	}

	public void setDoorNumber(String doorNumber) {
		this.doorNumber = doorNumber;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public int getPin() {
		return pin;
	}

	public void setPin(int pin) {
		this.pin = pin;
	}

	@Override
	public String toString() {
		return "Address [doorNumber=" + doorNumber + ", street=" + street + ", city=" + city + ", pin=" + pin + "]";
	}

}
