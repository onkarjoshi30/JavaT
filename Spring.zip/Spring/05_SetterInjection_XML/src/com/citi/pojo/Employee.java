package com.citi.pojo;

public class Employee {
	private int employeeId;
	private String name;
	private double salary;
	private Address address;

	public Employee() {
		System.out.println("Default constructor of Employee");
	}

	public Employee(int employeeId, String name, double salary, Address address) {
		System.out.println("Param. constrcutor of Employee");
		this.employeeId = employeeId;
		this.name = name;
		this.salary = salary;
		this.address = address;
	}

	public int getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(int employeeId) {
		System.out.println("Setting EmployeeId");
		this.employeeId = employeeId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		System.out.println("Setting Name");
		this.name = name;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		System.out.println("Setting Salary");
		this.salary = salary;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		System.out.println("Setting Address");
		this.address = address;
	}

	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", name=" + name + ", salary=" + salary + ", address=" + address
				+ "]";
	}

}



