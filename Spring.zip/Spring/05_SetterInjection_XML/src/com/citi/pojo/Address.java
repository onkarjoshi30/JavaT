package com.citi.pojo;

public class Address {
	private String doorNumber;
	private String street;
	private String city;
	private int pin;

	public Address() {
		System.out.println("Default constrctor of Address");
	}

	public Address(String doorNumber, String street, String city, int pin) {
		System.out.println("Param. construcotr of Address");
		this.doorNumber = doorNumber;
		this.street = street;
		this.city = city;
		this.pin = pin;
	}

	public String getDoorNumber() {
		return doorNumber;
	}

	public void setDoorNumber(String doorNumber) {
		System.out.println("Setting DoorNumber");
		this.doorNumber = doorNumber;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		System.out.println("Setting Street");
		this.street = street;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		System.out.println("Setting city");
		this.city = city;
	}

	public int getPin() {
		return pin;
	}

	public void setPin(int pin) {
		System.out.println("Setting Pin");
		this.pin = pin;
	}

	@Override
	public String toString() {
		return "Address [doorNumber=" + doorNumber + ", street=" + street + ", city=" + city + ", pin=" + pin + "]";
	}

}

