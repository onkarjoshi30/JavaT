package com.citi.main;

import java.util.Scanner;

import com.citi.application.Application;
import com.citi.service.EmailMessage;
import com.citi.service.MessageService;
import com.citi.service.SMSMessage;
import com.citi.service.WhatsappMessage;

public class ApplicationMain {
	public static void main(String[] args) {

		Application application = null;
		MessageService service = null;
		int choice;
		String message = "";
		String to = "";
		Scanner scanner = new Scanner(System.in);

		System.out.println("1. SMS Message");
		System.out.println("2. Email Message");
		System.out.println("3. Whatsapp Message");
		System.out.println("Enter your choice");
		choice = scanner.nextInt();

		switch (choice) {
		case 1:
			service = new SMSMessage();
			System.out.println("Enter Message for SMS");
			message = scanner.next();
			System.out.println("Enter to whom you want to send SMS");
			to = scanner.next();
			break;
		case 2:
			System.out.println("Enter Message for Email");
			message = scanner.next();
			System.out.println("Enter to whom you want to send Email");
			to = scanner.next();
			service = new EmailMessage();
			break;
		case 3:
			System.out.println("Enter Message for Whatsapp");
			message = scanner.next();
			System.out.println("Enter to whom you want to send Whatsapp");
			to = scanner.next();
			service = new WhatsappMessage();
			break;

		}
		application = new Application(service);
		application.processMessage(message, to);

	}
}
