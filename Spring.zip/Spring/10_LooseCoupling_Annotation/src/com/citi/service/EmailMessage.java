package com.citi.service;

public class EmailMessage implements MessageService {
	public void sendMessage(String message, String to) {
		System.out.println("Email Message with body :: " + message + " is sent to " + to);
	}
}