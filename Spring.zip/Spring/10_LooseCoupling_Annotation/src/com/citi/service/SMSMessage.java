package com.citi.service;

public class SMSMessage implements MessageService {
	public void sendMessage(String message, String to) {
		System.out.println("SMS Message with body :: " + message + " is sent to " + to);
	}
}