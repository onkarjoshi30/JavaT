package com.citi.service;

public interface MessageService {
	public void sendMessage(String message, String to);
}