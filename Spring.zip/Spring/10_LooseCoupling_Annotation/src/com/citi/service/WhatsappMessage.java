package com.citi.service;

public class WhatsappMessage implements MessageService {
	public void sendMessage(String message, String to) {
		System.out.println("Whatsappp Message with body :: " + message + " is sent to " + to);
	}
}
