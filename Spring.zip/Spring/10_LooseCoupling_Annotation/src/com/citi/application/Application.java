package com.citi.application;

import com.citi.service.MessageService;

public class Application {

	private MessageService message;

	public Application() {
	}

	public Application(MessageService message) {
		this.message = message;
	}

	public void processMessage(String msg, String to) {
		message.sendMessage(msg, to);
	}

	public MessageService getMessage() {
		return message;
	}

	public void setMessage(MessageService message) {
		this.message = message;
	}

}