package com.citi.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.citi.pojo.Address;


public class AddressMain {
    public static void main(String[] args) {
    	
        // creating Address object
        System.out.println("Creating Address Object");
        Address address = new Address();
        System.out.println(address);
        
        // injecting Address object
        System.out.println("Injecting Address Object from spring factory");
        ApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
        Address address2 =  context.getBean("address" , Address.class);
        System.out.println(address2);
        
        
    }
}