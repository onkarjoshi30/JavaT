package com.citi.main;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.citi.pojo.Employee;

public class EmployeeMain {
	public static void main(String[] args) {
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
		Employee employee = context.getBean("employee", Employee.class);

		System.out.println(employee);
	}
}